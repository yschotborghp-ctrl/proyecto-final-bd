# Enlaces del Proyecto Final de Bases de Datos

| Descripción | Enlace |
| :--- | :--- |
| **Repositorio GitHub** | `https://github.com/yschotborghp-ctrl/proyecto-final-bd/tree/main` |
| **Video de Sustentación** | `https://youtu.be/sustentacion_proyecto_final_bd` |
